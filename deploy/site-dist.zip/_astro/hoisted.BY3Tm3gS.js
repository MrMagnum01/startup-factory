const $=e=>document.getElementById(e).value.trim(),O=e=>e.replace(/&/g,"&amp;").replace(/</g,"&lt;");function B(e,t,r){return`<div class="card"><p class="mono text-[0.64rem] uppercase tracking-widest text-muted mb-2">${r}</p><p class="font-medium text-[0.95rem] mb-3">Subject: ${O(e)}</p><pre class="m-0 whitespace-pre-wrap font-sans text-[0.9rem] leading-relaxed text-ink-soft">${O(t)}</pre></div>`}let R="";function Q(){const e=$("ce-role"),t=$("ce-pain"),r=$("ce-offer"),n=$("ce-proof"),o=$("ce-cta"),a=$("ce-name"),i=document.getElementById("ce-out");if(!e||!t||!r||!o||!a){i.innerHTML='<p class="text-muted text-[0.92rem] card m-0">All fields except proof are required.</p>';return}const c=`quick question about ${t.split(" ").slice(0,4).join(" ")}`,s=`Hi {{first_name}},

{{first_line — one specific, researched sentence about THEIR business}}

Most ${e} I talk to are losing customers because they're ${t}. It usually isn't their fault — it's a handful of fixable issues nobody has pointed out.

I run ${r}.${n?` So far: ${n}.`:""}

${o.charAt(0).toUpperCase()+o.slice(1)}

${a}`,p=`re: ${c}`,l=`Hi {{first_name}},

In case it's useful even if we never work together — the three things I'd check first for any ${e.replace(/s$/,"")}:

1. {{specific check #1 for ${t}}}
2. {{specific check #2}}
3. {{specific check #3}}

If you'd rather I just do it: ${r}. ${o}

${a}`,E="closing the loop",_=`Hi {{first_name}},

I'll stop here — last thing from me.

If ${t} becomes a priority this quarter, the door's open and the details are below my signature. If not, genuinely no worries, and good luck with the season ahead.

${a}

—
${r}${n?` · ${n}`:""}`;i.innerHTML=B(c,s,"Email 1 · Day 0 — opener (PAS)")+B(p,l,"Email 2 · Day 3 — give value first")+B(E,_,"Email 3 · Day 7 — polite breakup"),R=`EMAIL 1 (Day 0)
Subject: ${c}

${s}

---

EMAIL 2 (Day 3)
Subject: ${p}

${l}

---

EMAIL 3 (Day 7)
Subject: ${E}

${_}`;try{window.track&&window.track("tool_used",{tool:"cold-email-generator"})}catch{}}document.getElementById("ce-gen").addEventListener("click",Q);document.getElementById("ce-copy").addEventListener("click",async()=>{if(R)try{await navigator.clipboard.writeText(R);const e=document.getElementById("ce-copy");e.textContent="Copied ✓",setTimeout(()=>e.textContent="Copy all",1500)}catch{}});const d=e=>document.getElementById(e),K=document.getElementById("iv-lines");function P(e="",t=1,r=0){const n=document.createElement("div");n.className="grid grid-cols-[1fr_70px_110px_34px] gap-2 iv-line",n.innerHTML=`
      <input placeholder="Description" value="${e}" class="iv-d px-3 py-2.5 rounded-[9px] border border-line-strong bg-paper text-[0.92rem]" />
      <input type="number" min="0" step="0.5" value="${t}" aria-label="Quantity" class="iv-q px-3 py-2.5 rounded-[9px] border border-line-strong bg-paper tnum text-[0.92rem]" />
      <input type="number" min="0" step="0.01" value="${r}" aria-label="Unit price" class="iv-p px-3 py-2.5 rounded-[9px] border border-line-strong bg-paper tnum text-[0.92rem]" />
      <button type="button" aria-label="Remove line" class="iv-x rounded-[9px] border border-line-strong hover:border-ink text-muted">×</button>`,K.appendChild(n),n.querySelectorAll("input").forEach(o=>o.addEventListener("input",q)),n.querySelector(".iv-x").addEventListener("click",()=>{n.remove(),q()}),q()}function D(){return[...document.querySelectorAll(".iv-line")].map(e=>({d:e.querySelector(".iv-d").value,q:+e.querySelector(".iv-q").value||0,p:+e.querySelector(".iv-p").value||0}))}function q(){const e=d("iv-cur").value,t=D().reduce((n,o)=>n+o.q*o.p,0),r=t*((+d("iv-tax").value||0)/100);d("iv-sub").textContent=e+t.toFixed(2),d("iv-taxv").textContent=e+r.toFixed(2),d("iv-total").textContent=e+(t+r).toFixed(2)}function J(){const e=d("iv-cur").value,t=D().reduce((o,a)=>o+a.q*a.p,0),r=t*((+d("iv-tax").value||0)/100),n=D().filter(o=>o.d||o.p).map(o=>`<tr><td style="padding:6px 0;border-bottom:1px solid #ddd">${o.d}</td><td style="text-align:right;border-bottom:1px solid #ddd">${o.q}</td><td style="text-align:right;border-bottom:1px solid #ddd">${e}${o.p.toFixed(2)}</td><td style="text-align:right;border-bottom:1px solid #ddd">${e}${(o.q*o.p).toFixed(2)}</td></tr>`).join("");document.getElementById("iv-paper").innerHTML=`
      <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:28px">
        <div><div style="font-size:30px;letter-spacing:-0.5px">Invoice</div><div style="font-family:monospace;font-size:12px;color:#555">${d("iv-num").value} · ${d("iv-date").value||""}${d("iv-due").value?" · due "+d("iv-due").value:""}</div></div>
      </div>
      <table style="width:100%;font-size:13px;margin-bottom:26px"><tr>
        <td style="vertical-align:top;white-space:pre-line"><strong>From</strong>
${d("iv-from").value}</td>
        <td style="vertical-align:top;white-space:pre-line;text-align:right"><strong>Bill to</strong>
${d("iv-to").value}</td></tr></table>
      <table style="width:100%;border-collapse:collapse;font-size:13px">
        <tr style="font-family:monospace;font-size:11px;text-transform:uppercase;color:#555"><td style="border-bottom:2px solid #111;padding:4px 0">Description</td><td style="text-align:right;border-bottom:2px solid #111">Qty</td><td style="text-align:right;border-bottom:2px solid #111">Price</td><td style="text-align:right;border-bottom:2px solid #111">Amount</td></tr>
        ${n}
      </table>
      <div style="margin-top:18px;text-align:right;font-size:14px">Subtotal ${e}${t.toFixed(2)} &nbsp; Tax ${e}${r.toFixed(2)}<div style="font-size:22px;margin-top:6px"><strong>Total ${e}${(t+r).toFixed(2)}</strong></div></div>
      <div style="margin-top:26px;font-size:12px;color:#444;white-space:pre-line">${d("iv-notes").value}</div>`}document.getElementById("iv-add").addEventListener("click",()=>P());document.getElementById("iv-print").addEventListener("click",()=>{J();try{window.track&&window.track("tool_used",{tool:"invoice-generator"})}catch{}window.print()});["iv-tax","iv-cur"].forEach(e=>d(e).addEventListener("input",q));const X=new Date().toISOString().slice(0,10);d("iv-date").value=X;P("Design & development",1,500);const u=e=>document.getElementById(e),h=e=>e.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;");function F(){const e=u("mt-title").value.trim(),t=u("mt-desc").value.trim(),r=u("mt-url").value.trim(),n=u("mt-img").value.trim(),o=u("mt-site").value.trim(),a=u("mt-type").value;u("mt-title-c").textContent=`(${e.length}/60${e.length>60?" — too long":""})`,u("mt-desc-c").textContent=`(${t.length}/160${t.length>160?" — too long":""})`,u("mt-prev-title").textContent=e||"Your title appears here",u("mt-prev-desc").textContent=t||"Your description appears here — make it earn the click.";let i="example.com";try{i=new URL(r).hostname}catch{}u("mt-prev-url").textContent=i+(r?new URL(r).pathname:""),u("mt-prev-host").textContent=i,u("mt-prev-card-title").textContent=e||"Your title";const c=u("mt-prev-imgbox");c.innerHTML=n?`<img src="${h(n)}" alt="" style="width:100%;height:100%;object-fit:cover" onerror="this.replaceWith('image failed to load')">`:"og:image preview";const s=[];e&&s.push(`<title>${h(e)}</title>`),t&&s.push(`<meta name="description" content="${h(t)}">`),r&&s.push(`<link rel="canonical" href="${h(r)}">`),s.push(`<meta property="og:type" content="${a}">`),o&&s.push(`<meta property="og:site_name" content="${h(o)}">`),e&&s.push(`<meta property="og:title" content="${h(e)}">`),t&&s.push(`<meta property="og:description" content="${h(t)}">`),r&&s.push(`<meta property="og:url" content="${h(r)}">`),n&&s.push(`<meta property="og:image" content="${h(n)}">`,'<meta property="og:image:width" content="1200">','<meta property="og:image:height" content="630">'),s.push(`<meta name="twitter:card" content="${n?"summary_large_image":"summary"}">`),e&&s.push(`<meta name="twitter:title" content="${h(e)}">`),t&&s.push(`<meta name="twitter:description" content="${h(t)}">`),n&&s.push(`<meta name="twitter:image" content="${h(n)}">`),document.getElementById("mt-code").textContent=s.join(`
`)}["mt-title","mt-desc","mt-url","mt-img","mt-site","mt-type"].forEach(e=>u(e).addEventListener("input",F));document.getElementById("mt-copy").addEventListener("click",async()=>{try{await navigator.clipboard.writeText(document.getElementById("mt-code").textContent||"");const e=document.getElementById("mt-copy");e.textContent="Copied ✓",setTimeout(()=>e.textContent="Copy",1500),window.track&&window.track("tool_used",{tool:"meta-tags"})}catch{}});F();const y=e=>document.getElementById(e),w=e=>"$"+Math.round(e).toLocaleString("en-US");function H(e,t,r,n){let o=0,a=0,i=e;const c=12*80;for(;i>0&&o<c;){const s=i*t;a+=s,i=i+s-(r+n),o++}return{months:o,interest:a}}function W(){const e=+y("mp-bal").value||0,t=(+y("mp-apr").value||0)/100,r=Math.max(1,+y("mp-years").value||1),n=+y("mp-extra").value||0,o=t/12,a=r*12,i=o>0?e*o/(1-Math.pow(1+o,-a)):e/a,c=H(e,o,i,0),s=H(e,o,i,n),p=Math.max(0,c.months-s.months),l=new Date;l.setMonth(l.getMonth()+s.months),y("mp-pay").textContent=w(i+n)+` (${w(i)} + ${w(n)} extra)`,y("mp-when").textContent=l.toLocaleDateString("en-US",{month:"short",year:"numeric"}),y("mp-saved-t").textContent=`${Math.floor(p/12)}y ${p%12}m`,y("mp-saved-i").textContent=w(Math.max(0,c.interest-s.interest)),y("mp-int-was").textContent=w(c.interest),y("mp-int-now").textContent=w(s.interest);try{window.track&&window.track("tool_used",{tool:"mortgage-payoff"})}catch{}}["mp-bal","mp-apr","mp-years","mp-extra"].forEach(e=>y(e)?.addEventListener("input",W));W();const I=e=>document.getElementById(e);let S={privacy:"",terms:""},T="privacy";const U=()=>new Date().toISOString().slice(0,10);function Z(){const e=I("pg-name").value.trim()||"[SITE NAME]",t=I("pg-url").value.trim()||"[URL]",r=I("pg-email").value.trim()||"[EMAIL]",n=c=>I(c).checked,o=[];o.push(`PRIVACY POLICY — ${e}
Last updated: ${U()}
`),o.push(`This policy explains what ${e} ("we", "us") at ${t} collects and why.
`),o.push("1. WHAT WE COLLECT");const a=[];n("pg-analytics")&&a.push("- Aggregate usage analytics (pages visited, referrer, device class). Where possible we use privacy-respecting, cookieless analytics. IP addresses are not stored by us."),n("pg-forms")&&a.push("- Information you submit through forms (such as your email address when joining a list). We use it only for the purpose stated next to the form."),n("pg-payments")&&a.push("- Purchases are processed by our payment providers (e.g. Stripe, Gumroad, Lemon Squeezy). We never see or store your full card details; we receive order metadata (item, amount, your email) to fulfil your purchase."),n("pg-accounts")&&a.push("- Account data you provide (email, display name) and content you create in the product."),a.length||a.push("- We do not collect personal information. This site runs without trackers, forms or accounts."),o.push(a.join(`
`)),o.push(`
2. WHAT WE DON'T DO
- We do not sell or rent your personal data.
- We do not use your data for third-party advertising.
- We collect the minimum needed to operate ${e}.`),n("pg-cookies")?o.push(`
3. COOKIES
We set some non-essential cookies (for example to remember preferences${n("pg-analytics")?" and measure usage":""}). You can block cookies in your browser; core functionality will still work.`):o.push(`
3. COOKIES
We do not set non-essential cookies.`),o.push(`
4. THIRD PARTIES
Service providers we rely on (hosting${n("pg-payments")?", payment processing":""}${n("pg-analytics")?", analytics":""}${n("pg-forms")?", form handling":""}) process data under their own policies and our instructions.`),o.push(`
5. YOUR RIGHTS
Depending on your location (e.g. GDPR/UK GDPR/CCPA) you may have rights to access, correct, export or delete your data. Email ${r} and we will respond within 30 days.`),o.push(`
6. DATA RETENTION
Form submissions are kept while relevant to their purpose; you can request deletion at any time.${n("pg-accounts")?" Account data is deleted within 30 days of account deletion.":""}`),o.push(`
7. CHANGES
We will post any changes on this page and update the date above.

8. CONTACT
${r}`);const i=[];i.push(`TERMS OF SERVICE — ${e}
Last updated: ${U()}
`),i.push(`1. AGREEMENT
By using ${t} you agree to these terms. If you do not agree, do not use the service.`),i.push(`
2. THE SERVICE
${e} is provided "as is" and "as available", without warranties of any kind, express or implied. We may change or discontinue features at any time.`),n("pg-payments")&&i.push(`
3. PURCHASES & REFUNDS
Prices are shown at checkout. Payments are handled by our payment providers. Unless stated otherwise on the product page, digital purchases include a 14-day refund window — contact ${r}.`),n("pg-accounts")&&i.push(`
${n("pg-payments")?"4":"3"}. ACCOUNTS
You are responsible for your account and for keeping credentials secure. We may suspend accounts that abuse the service.`),i.push(`
${n("pg-payments")&&n("pg-accounts")?"5":n("pg-payments")||n("pg-accounts")?"4":"3"}. ACCEPTABLE USE
No unlawful use, no attempts to disrupt the service, no scraping at abusive volumes, no infringing content.`),i.push(`
LIMITATION OF LIABILITY
To the maximum extent permitted by law, our total liability for any claim related to the service is limited to the amount you paid us in the 12 months before the claim (or $0 for free use).`),i.push(`
GOVERNING LAW
These terms are governed by the laws of [YOUR JURISDICTION — fill in].`),i.push(`
CONTACT
${r}`),S={privacy:o.join(`
`),terms:i.join(`
`)},N();try{window.track&&window.track("tool_used",{tool:"policy-generator"})}catch{}}function N(){document.getElementById("pg-out").value=S[T]}document.getElementById("pg-gen").addEventListener("click",Z);document.querySelectorAll(".pg-tab").forEach(e=>e.addEventListener("click",()=>{T=e.dataset.tab,document.querySelectorAll(".pg-tab").forEach(t=>{t.classList.toggle("tag--accent",t===e),t.setAttribute("aria-pressed",String(t===e))}),N()}));document.getElementById("pg-copy").addEventListener("click",async()=>{if(S[T])try{await navigator.clipboard.writeText(S[T]);const e=document.getElementById("pg-copy");e.textContent="Copied ✓",setTimeout(()=>e.textContent="Copy",1500)}catch{}});const v=e=>document.getElementById(e),x=e=>"$"+(Math.round(e/5)*5).toLocaleString("en-US");let z="";function Y(){const e=+v("qe-rate").value||0,t=+v("qe-hours").value||0,r=+v("qe-complex").value||1,n=v("qe-rush").checked?1.25:1,o=v("qe-client").checked?1.15:1,a=e*t,i=a*1.2,c=i*r*n*o,s=c*.95,p=c*1.15;v("qe-quote").textContent=x(c),v("qe-range").textContent=`sane range: ${x(s)} – ${x(p)}`,v("qe-base").textContent=x(a),v("qe-buffer").textContent=x(i-a),v("qe-deposit").textContent=x(c/2),z=`Project quote
— Scope estimate: ${t}h
— Fixed price: ${x(c)}
— 50% deposit to start: ${x(c/2)}
— Balance on delivery.
(Price includes complexity & risk buffer; scope changes re-quoted.)`;try{window.track&&window.track("tool_used",{tool:"quote-estimator"})}catch{}}["qe-rate","qe-hours","qe-complex","qe-rush","qe-client"].forEach(e=>v(e)?.addEventListener("input",Y));document.getElementById("qe-copy")?.addEventListener("click",async()=>{try{await navigator.clipboard.writeText(z);const e=document.getElementById("qe-copy");e.textContent="Copied ✓",setTimeout(()=>e.textContent="Copy quote summary",1600)}catch{}});Y();const g=e=>document.getElementById(e),k=e=>"$"+Math.ceil(e).toLocaleString("en-US");function G(){const e=+g("rc-income").value||0,t=Math.max(1,+g("rc-hours").value||1),r=Math.min(51,+g("rc-weeks").value||0),n=(+g("rc-overhead").value||0)/100,o=(+g("rc-tax").value||0)/100;g("rc-tax-v").textContent=String(Math.round(o*100));const a=t*(52-r),c=e*(1+n)/Math.max(.05,1-o)/a;g("rc-hourly").textContent=k(c)+"/h",g("rc-day").textContent=k(c*7),g("rc-week").textContent=k(c*t),g("rc-proj").textContent=k(c*10),g("rc-note").textContent=`Based on ${a.toLocaleString()} billable hours/year. Quote projects, not hours, where you can.`;try{window.track&&window.track("tool_used",{tool:"rate-calculator"})}catch{}}["rc-income","rc-hours","rc-weeks","rc-overhead","rc-tax"].forEach(e=>g(e)?.addEventListener("input",G));G();const C=e=>document.getElementById(e).value.trim(),j={impact:["Drove","Boosted","Increased","Accelerated","Delivered"],build:["Built","Shipped","Launched","Engineered","Created"],lead:["Led","Directed","Owned","Coordinated","Spearheaded"],analyze:["Analyzed","Optimized","Streamlined","Redesigned","Automated"]},ee=e=>e.charAt(0).toUpperCase()+e.slice(1),L=e=>e.replace(/^(i\s+|we\s+)/i,"").replace(/\.+$/,"");function te(){const e=L(C("rb-task")),t=L(C("rb-metric")),r=L(C("rb-how")),n=L(C("rb-scope")),o=document.getElementById("rb-out");if(!e||!t){o.innerHTML='<li class="text-muted">Both “what you did” and a measurable result are required — numbers are what recruiters scan for.</li>';return}const a=j[C("rb-tone")]??j.impact,i=s=>s.replace(/\s+/g," ").trim().replace(/\s,/g,","),c=[i(`${a[0]} ${t} by ${r||e}${n?", "+n:""}.`),i(`${a[1]} ${e}${n?" "+n:""}, ${t.match(/^\d|%|\$/)?"achieving ":"resulting in "}${t}.`),i(`${a[2]} ${t} ${r?`through ${r}`:`by ${e}`}.`),i(`${a[3]} ${e}${r?` using ${r}`:""} — ${t}${n?` (${n})`:""}.`),i(`${a[4]} measurable gains (${t})${r?` via ${r}`:""} while ${e.replace(/^([a-z]+)(ed|ing)?\b/i,s=>s.replace(/ed$/,"ing"))}.`)];o.innerHTML=c.map(s=>`<li class="flex gap-2.5"><span class="text-accent mt-0.5">▪</span><span>${ee(s)}</span></li>`).join("");try{window.track&&window.track("tool_used",{tool:"resume-bullets"})}catch{}}document.getElementById("rb-gen").addEventListener("click",te);document.getElementById("rb-copy").addEventListener("click",async()=>{const e=[...document.querySelectorAll("#rb-out li span:last-child")].map(t=>"• "+t.textContent).join(`
`);if(e.includes("•"))try{await navigator.clipboard.writeText(e);const t=document.getElementById("rb-copy");t.textContent="Copied ✓",setTimeout(()=>t.textContent="Copy all",1500)}catch{}});const m=e=>document.getElementById(e),A=e=>"$"+Math.round(e).toLocaleString("en-US");function V(){const e=+m("sm-arpu").value||0,t=Math.max(.001,(+m("sm-churn").value||0)/100),r=(+m("sm-margin").value||0)/100,n=+m("sm-cac").value||0,o=+m("sm-cust").value||0,a=+m("sm-growth").value||0,i=1/t,c=e*r*i,s=n>0?c/n:1/0,p=e*r>0?n/(e*r):1/0;let l=o;for(let E=0;E<12;E++)l=l*(1-t)+a;m("sm-mrr").textContent=A(e*o),m("sm-life").textContent=i.toFixed(1)+" months",m("sm-ltv").textContent=A(c),m("sm-ratio").textContent=isFinite(s)?s.toFixed(1)+" : 1":"∞",m("sm-payback").textContent=isFinite(p)?p.toFixed(1)+" months":"—",m("sm-proj").textContent=A(e*l)+"/mo",m("sm-verdict").textContent=s>=3&&p<=12?"Healthy: LTV:CAC ≥ 3 and payback under a year. Scaling spend is defensible.":s>=3?"LTV:CAC is fine but payback is slow — watch cash.":"Under 3:1 — fix churn or pricing before buying growth.";try{window.track&&window.track("tool_used",{tool:"saas-metrics"})}catch{}}["sm-arpu","sm-churn","sm-margin","sm-cac","sm-cust","sm-growth"].forEach(e=>m(e)?.addEventListener("input",V));V();const f=e=>document.getElementById(e);let b="";function ne(){const e=f("ut-lower").checked,t=l=>(l=l.trim().replace(/\s+/g,"_"),e?l.toLowerCase():l),r=f("ut-url").value.trim(),n=t(f("ut-source").value),o=t(f("ut-medium").value),a=t(f("ut-campaign").value),i=t(f("ut-content").value),c=f("ut-out"),s=document.getElementById("ut-copy"),p=document.getElementById("ut-qr-btn");if(b="",!r||!n||!o||!a){c.textContent="Fill the required fields…",s.setAttribute("aria-disabled","true"),p.setAttribute("aria-disabled","true");return}try{const l=new URL(r);l.searchParams.set("utm_source",n),l.searchParams.set("utm_medium",o),l.searchParams.set("utm_campaign",a),i&&l.searchParams.set("utm_content",i),b=l.toString(),c.textContent=b,s.removeAttribute("aria-disabled"),p.removeAttribute("aria-disabled")}catch{c.textContent="That URL doesn't look valid (include https://)."}}["ut-url","ut-source","ut-medium","ut-campaign","ut-content","ut-lower"].forEach(e=>f(e).addEventListener("input",ne));document.getElementById("ut-copy").addEventListener("click",async()=>{if(b)try{await navigator.clipboard.writeText(b);const e=document.getElementById("ut-copy");e.textContent="Copied ✓",setTimeout(()=>e.textContent="Copy link",1500),window.track&&window.track("tool_used",{tool:"utm-builder"})}catch{}});let M=null;document.getElementById("ut-qr-btn").addEventListener("click",async()=>{if(!b)return;const e=document.getElementById("ut-qr-card"),t=document.getElementById("ut-qr");e.classList.remove("hidden"),t.innerHTML='<span class="mono text-[0.75rem] text-muted">loading…</span>';try{M||(await new Promise((n,o)=>{const a=document.createElement("script");a.src="https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.min.js",a.onload=n,a.onerror=o,document.head.appendChild(a)}),M=window.qrcode);const r=M(0,"M");r.addData(b),r.make(),t.innerHTML=r.createImgTag(5,8)}catch{t.innerHTML='<span class="text-[0.85rem] text-ink-soft">QR library unavailable offline — the tracked link still works. Try again online.</span>'}});
